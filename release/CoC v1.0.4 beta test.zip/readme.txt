***Universal Hub***
A room of blank doors with one fixed door leading to the Norn Meso.
If you would like to use a door for your metaroom please contact Zzzzoot.

***Catilipac***
A whole new room to explore!
Requires the Universal Hub.
Images by Silvak
Code by Zzzzoot

***Daedolous***
A whole new room to explore!
Requires the Universal Hub.
Images by Silvak
Code by Zzzzoot

***Morpheri***
A whole new room to explore!
Requires the Universal Hub.
Concept for Children of Capilata by Silvak
Images by Zequr
Code by Zzzzoot

***Instalation***
The Universal Hub must be injected into your world before any of the other metarooms.
Copy CoC_UH.agents, CoC_CAT.agaents, CoC_DAE.agents, and CoC_MOR.agents to your "My Agents" folder.

Contact Zzzzoot at gantt42@gmail.com
